<html>
	<head>
		<title>Erstellen eines neuen Contact-Handles</title>
	</head>

<body>

<h1>Erstellen eines neuen Contact-Handles</h1>

<form method="GET" action="">
	<table>
		<tr>
			<td>Vorname:</td>
			<td><input type="text" name="firstname" value="firstname"/></td>
		</tr>
		<tr>
			<td>Nachname:</td>
			<td><input type="text" name="lastname" value="lastname"/></td>
		</tr>
		<tr>
			<td>Stra&szlig;e:</td>
			<td><input type="text" name="street" value="street"/></td>
		</tr>
		<tr>
			<td>PLZ:</td>
			<td><input type="text" name="zip" value="zip"/></td>
		</tr>
		<tr>
			<td>Ort:</td>
			<td><input type="text" name="city" value="city"/></td>
		</tr>
		<tr>
			<td>Land:</td>
			<td><input type="text" name="country" value="DE"/></td>
		</tr>
		<tr>
			<td>Tel:</td>
			<td><input type="text" name="phone" value="000011111"/></td>
		</tr>
		<tr>
			<td>Email:</td>
			<td><input type="text" name="email" value="email@email.de"/></td>
		</tr>
		<tr>
			<td colspan="2"><input type="submit" name="absenden" value="absenden"></td>
		</tr>
	</table>
</form>

<?php

/*--------------------------------------------------------------*
*  Authentifizierungs-Variablen                                 *
*--------------------------------------------------------------*/
$user = '';
$pass = '';


/*--------------------------------------------------------------*
*  Socketpfad                                                   *
*--------------------------------------------------------------*/
$mreg_config = array('socket' => 'https://api.domainreselling.de/api/call.cgi?s_login='.$user.'&s_pw='.$pass);

/*--------------------------------------------------------------*
*  Include Reg-Bibliothek                                       *
*--------------------------------------------------------------*/
require_once('../lib/libmreg.inc.php');

/*--------------------------------------------------------------*
*  GET-Vars-Auswertung                                          *
*--------------------------------------------------------------*/
extract($_GET, EXTR_OVERWRITE);

/*--------------------------------------------------------------*
*  Formular wird gesendet                                       *
*--------------------------------------------------------------*/
if ($_GET['absenden']) {

	/*--------------------------------------------------------------*
	*  Aufbau des Command-Arrays mit Formularvariablen              *
	*--------------------------------------------------------------*/
	$command = array('command' => 'addcontact',
						  'firstname' => $firstname,
						  'lastname' => $lastname,
						  'street' => $street,
						  'zip' => $zip,
						  'city' => $city,
						  'country' => $country,
						  'phone' => $phone,
						  'email' => $email);	


	/*--------------------------------------------------------------*
	*  Funktionsaufruf - Command-Ausführung mit                     *
	*  Command-Array und Socket-Pfad                                *
	*  Speicherung der Response in die Array-Variable $hash         *
	*--------------------------------------------------------------*/
	$hash = mreg_call($command, $mreg_config);
	
	/*--------------------------------------------------------------*
	*  Ausgabe des Responscodes                                     *
	*--------------------------------------------------------------*/
	echo 'Responsecode: '.$hash['CODE'].' '.$hash['DESCRIPTION'].'<br>';
	
	// Code 200 wird generell zurückgegeben, wenn die Ausführung des
	// Kommandos erfolgreich war.
	if ($hash['CODE'] == 200) {		
	
		/*--------------------------------------------------------------*
		*  Ausgabe des Contacthandles                                   *
		*--------------------------------------------------------------*/
		echo 'Contacthandle: '.$hash['PROPERTY']['CONTACT'][0].'<br>';
	
		$chandle = $hash['PROPERTY']['CONTACT'][0];
	
		echo '
		Das angelegte Contacthandle kann nun f&uuml;r die Domainregistrierung
		herangezogen werden.<br><br>
		**************************************************************<br>
		z.B.:<br><br>
		$command = array(<br>
		\'command\' => \'adddomain\',<br>
		\'domain\' => \'testdomain.de\',<br>
		\'period\' => \'1\',<br>
		\'nameserver0\' => \'ns1a.dodns.net\',<br>
		\'nameserver1\' => \'ns2a.dodns.net\',<br>
		\'ownercontact0\' => \''.$chandle.'\',<br>
		\'admincontact0\' => \''.$chandle.'\',<br>
		\'techcontact0\' => \''.$chandle.'\',<br>
		\'billingcontact0\' => \''.$chandle.'\',<br>
		);<br>
		$hash = mreg_call($command, $mreg_config);
		<br>
		**************************************************************<br><br>
		Die $hash Variable liefert wieder das entsprechende Ergebnis<br>
		des Commandos zur&uuml;ck und kann mit $hash[\'CODE\'] und<br>
		$hash[\'DESCRIPTION\'] ausgelesen werden.)';
	}
	// Return Code ungleich 200. Kommando nicht erfolgreich ausgeführt.
	else {
		
		echo 'Das Kommando wurde nicht erfolgreich ausgef&uuml;hrt. Bitte &uuml;berpr&uuml;fen Sie
			in diesem Fall als erstes, ob die im Script eingetragenen Authentifizierungswerte
			(Login) korrekt sind. Eine Liste der m&ouml;glichen R&uuml;ckgabewerte finden Sie im
			Reseller-Interface unter HELPDESK / SOCKET COMMANDS / ALLGEMEINES / &Uuml;bersicht
			Return Codes . Bei Fragen wenden Sie sich bitte an den 
			<a href="mailto:support@ud-reselling.com">united-domains Reselling Support</a>.';
	}
}

?>

 </body>
</html>
