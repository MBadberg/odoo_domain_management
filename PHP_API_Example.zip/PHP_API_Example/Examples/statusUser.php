<html>
	<head>
		<title>Auswertung von Systemcommandos am Beispiel von statusUser</title>
	</head>

<body>

<h1>Auswertung von Systemcommandos am Beispiel von statusUser</h1>

<?php

/*--------------------------------------------------------------*
*  Authentifizierungs-Variablen                                 *
*--------------------------------------------------------------*/
$user = '';
$pass = '';

/*--------------------------------------------------------------*
*  Socketpfad                                                   *
*--------------------------------------------------------------*/
$mreg_config = array('socket' => 'https://api.domainreselling.de/api/call.cgi?s_login='.$user.'&s_pw='.$pass);

/*--------------------------------------------------------------*
*  Include Reg-Bibliothek                                       *
*--------------------------------------------------------------*/
require_once('../lib/libmreg.inc.php');

/*--------------------------------------------------------------*
*  Aufbau des Command-Arrays mit Formularvariablen              *
*--------------------------------------------------------------*/
$command = array('command' => 'statusUser');	

/*--------------------------------------------------------------*
*  Funktionsaufruf - Command-Ausführung mit                     *
*  Command-Array und Socket-Pfad                                *
*  Speicherung der Response in die Array-Variable $hash         *
*--------------------------------------------------------------*/
$hash = mreg_call($command, $mreg_config);

/*--------------------------------------------------------------*
*  Ausgabe des Responscodes                                     *
*--------------------------------------------------------------*/

?>

<h2>Dump der Ausgabe von statusUser</h2>
(mit StatusUser k&ouml;nnen Sie Ihre Preise, Guthabensstand usw. vom System abfragen)

<pre>
<?php
 print_r($hash);
?>
</pre>

