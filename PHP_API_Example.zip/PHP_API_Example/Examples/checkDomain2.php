<html>
 <head>
  <title>Domains auf Registrierbarkeit pr&uuml;fen (multiple Domain-Endungen)</title>
 </head>
 <body>
 <h1>Domains auf Registrierbarkeit pr&uuml;fen (multiple Domain-Endungen)</h1>
<form method="GET" action="">
Bitte geben Sie einen Domain-Namen ein: <input type="text" name="domain" value="testdomain"/>
<input type="submit">
</form>

<?php
$user = '';
$pass = '';

$mreg_config = array('socket' => 'https://api.domainreselling.de/api/call.cgi?s_login='.$user.'&s_pw='.$pass);

if ($_GET['domain']) {
	extract($_GET, EXTR_OVERWRITE);

	/*--------------------------------------------------------------*
	*  Domain-Name wird geparsed                                    *
	*--------------------------------------------------------------*/
	$domain = preg_replace( '/\..*/', '', $domain );
	$domain = preg_replace( '/[^a-z0-9\-]/', '', $domain );

	/*--------------------------------------------------------------*
	*  Include Reg-Bibliothek                                       *
	*--------------------------------------------------------------*/
	require_once('../lib/libmreg.inc.php');

	/*--------------------------------------------------------------*
	*  Array mit zu prüfenden Zonen                                 *
	*--------------------------------------------------------------*/
	$zones = array('de','com','net','org','info','biz','guru');

	$domains = array();
	$command = array('command' => 'CheckDomains');


	/*--------------------------------------------------------------*
	*  Include Reg-Bibliothek                                       *
	*--------------------------------------------------------------*/
	foreach ($zones as $index => $zone) {
        $command['domain'.$index] = $domain.'.'.$zone;
        $domains[$index] = $domain.'.'.$zone;
	}

	/*--------------------------------------------------------------*
	*  Funktionsaufruf - Command-Ausführung mit                     *
	*  Command-Array und Socket-Pfad                                *
	*  Speicherung der Response in die Array-Variable $hash         *
	*--------------------------------------------------------------*/
	$hash = mreg_call($command, $mreg_config);

	echo $hash['CODE'].' '.$hash['DESCRIPTION'].'<BR><BR>';

	// Code 200 wird generell zurückgegeben, wenn die Ausführung des
	// Kommandos erfolgreich war.
	if ($hash['CODE'] == 200) {

		foreach ( $hash['PROPERTY']['DOMAINCHECK'] as $index => $status ) {

			echo $domains[$index].': '.$status;

			if (preg_match( '/^210 /', $status)) {

				echo ' <B>Bestellen Sie  '.$domains[$index].' jetzt!</B><BR>';
			}
			else {

				echo '<BR>';
			}
		}
	}
	// Return Code ungleich 200. Kommando nicht erfolgreich ausgeführt.
	else {

		echo 'Das Kommando wurde nicht erfolgreich ausgef&uuml;hrt. Bitte &uuml;berpr&uuml;fen Sie
				in diesem Fall als erstes, ob die im Script eingetragenen Authentifizierungswerte
				(Login) korrekt sind. Eine Liste der m&ouml;glichen R&uuml;ckgabewerte finden Sie im
				Reseller-Interface unter HELPDESK / SOCKET COMMANDS / ALLGEMEINES / &Uuml;bersicht
				Return Codes . Bei Fragen wenden Sie sich bitte an den
				<a href="mailto:support@ud-reselling.com">united-domains Reselling Support</a>.';

echo '<br /><br />';

echo 'Fehlercode: '.$hash['CODE'].'<br />';
echo 'Beschreibung: '.$hash['DESCRIPTION'];

	}
}

?>

</body>
</html>
