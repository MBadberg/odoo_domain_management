<html>
 <head>
  <title>Domains auf Registrierbarkeit pr&uuml;fen</title>
 </head>
 <body>
 
<h1>Domains auf Registrierbarkeit pr&uuml;fen</h1>

<form method="GET" action="">
Bitte geben Sie den gew&uuml;nschten Domain-Namen ein: <input type="text" name="domain" value="testexample.net"/>
<input type="submit">
</form>

<?php

$user = '';
$pass = '';

$mreg_config = array('socket' => 'https://api.domainreselling.de/api/call.cgi?s_login='.$user.'&s_pw='.$pass);

if ($_GET['domain']) {
	
	extract($_GET, EXTR_OVERWRITE);

	/*--------------------------------------------------------------*
	*  Include Reg-Bibliothek                                       *
	*--------------------------------------------------------------*/
	require_once('../lib/libmreg.inc.php');
	
	/*--------------------------------------------------------------*
	*  Aufbau des Command-Arrays mit Formularvariablen              *
	*--------------------------------------------------------------*/
		
	$command = array('command' => 'CheckDomain', 
						  'domain' => $domain);

	/*--------------------------------------------------------------*
	*  Funktionsaufruf - Command-Ausführung mit                     *
	*  Command-Array und Socket-Pfad                                *
	*  Speicherung der Response in die Array-Variable $hash         *
	*--------------------------------------------------------------*/
	$hash = mreg_call($command, $mreg_config);

	// Code 210 (verfügbar) oder 211 (nicht verfügbar) werden zurückgegeben, 
	//	wenn die Ausführung des Kommandos erfolgreich war.
	if ($hash['CODE'] == 210 || $hash['CODE'] == 211) {
	
		echo $hash['CODE'].' '.$hash['DESCRIPTION'].' ';
		
		// Domain kann registriert werden
		if ($hash['CODE'] == 210) {
		
			echo '-- <B>Bestellen Sie  '.$domain.' jetzt!</B><BR>';
		}
		
		// Domain ist nicht verfügbar
		if ($hash['CODE'] == 211) {
		
			echo '-- <B>'.$domain.' ist leider nicht verf&uuml;gbar.</B><BR>';
		}
	}
	// Return Code ungleich 210 und 211. Kommando nicht erfolgreich ausgeführt.
	else {
		
		echo 'Das Kommando wurde nicht erfolgreich ausgef&uuml;hrt. Bitte &uuml;berpr&uuml;fen Sie
			in diesem Fall als erstes, ob die im Script eingetragenen Authentifizierungswerte
			(Login) korrekt sind. Eine Liste der m&ouml;glichen R&uuml;ckgabewerte finden Sie im
			Reseller-Interface unter HELPDESK / SOCKET COMMANDS / ALLGEMEINES / &Uuml;bersicht
			Return Codes . Bei Fragen wenden Sie sich bitte an den 
			<a href="mailto:support@ud-reselling.com">united-domains Reselling Support</a>.';
	}
}

?>

 </body>
</html>
