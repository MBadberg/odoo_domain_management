<?php
/**
 * mREG Socket Class Wrapper
 * @author 		Stefan Meinecke <meinecke@united-domains.de>
 * @author 		Tobias Sattler <sattler@united-domains.de>
 * @author 		Tim-Oliver Ettel <ettel@ud-reselling.com>
 * @package 		mreg
 * @copyright		Copyright (c) 2016 united-domains Reselling GmbH, Starnberg.
 * @version		$Id$
 */

/* Only use for compatibility between new libmreg.class and old scripts */

// load new class
require_once('libmreg.Class.php');
// allocate global instance
$oMREG = new mreg('hash');
$oMREG->setApiType('hash');

function mreg_call ($aCommand, $aConfig) {
	return $GLOBALS['oMREG']->mreg_call( $aCommand, $aConfig );
}

function mreg_call_raw ( $aCommand, $aConfig) {
	return $GLOBALS['oMREG']->mreg_call_raw( $aCommand, $aConfig );
}

function mreg_post_http ($sURL) {
    if ( preg_match('/^http:\/\/([^\/]+)([^\?]+)\?(.+)/', $sURL, $m )) {
		return $GLOBALS['oMREG']->mreg_call_raw( $m[3], array( 'socket' => 'http://'. $m[1] . '/'. $m[2] ) );
	}
}

function mreg_call_raw_http ($sCommand, $aConfig) {
	return $GLOBALS['oMREG']->mreg_call_raw( $GLOBALS['oMREG']->mreg_parse_command( $sCommand ), $aConfig );
}

function mreg_call_raw_exec($sCommand, $aConfig) {
    if( !isset($aConfig['socket']) ) {
    	return false;
    }

    if ( preg_match( "/^exec\:(.*)/", $aConfig['socket'], $m ) ) {
        $prg = $m[1];
        $cmd = "$prg << END\n[COMMAND]\n".$command."\nEOF\nEND\n";
        $response = "";

        $fp = popen($cmd, "r");
        while ( $line = fgets($fp, 32768) ) {
            $response .= $line;
        }
        pclose($fp);
        return $response;
    }
    return false;
}

function mreg_create_command( $aCommand ) {
	return $GLOBALS['oMREG']->mreg_create_command( $aCommand );
}

function mreg_parse_response ( $sRes ) {
	return $GLOBALS['oMREG']->mreg_parse_response( $sRes );
}
?>
